import deepy.data.dataset
import deepy.data.transform

from deepy.data.dataset import SelfSupervisedDataset
from deepy.data.dataset import InverseDataset
from deepy.data.toydataset import ToyClassDataset, ToyRegDataset